const categories = {
    homme: {
        title: "Produits pour Homme",
        count: 20,
        images: ['img1.jpg', 'img2.jpg', 'img3.jpg', 'img4.jpg']
    },
    femme: {
        title: "Produits pour Femme",
        count: 15,
        images: ['img5.jpg', 'img6.jpg', 'img7.jpg', 'img8.jpg']
    },
    generaliste: {
        title: "Produits Généralistes",
        count: 30,
        images: ['img9.jpg', 'img10.jpg', 'img11.jpg', 'img12.jpg']
    }
};

document.getElementById('homme').addEventListener('click', () => displayCategoryInfo('homme'));
document.getElementById('femme').addEventListener('click', () => displayCategoryInfo('femme'));
document.getElementById('generaliste').addEventListener('click', () => displayCategoryInfo('generaliste'));

function displayCategoryInfo(categoryKey) {
    const category = categories[categoryKey];
    document.getElementById('category-title').textContent = category.title;
    document.getElementById('product-count').textContent = `Nombre de produits: ${category.count}`;
    const imagesContainer = document.getElementById('product-images');
    imagesContainer.innerHTML = '';  // Clear previous images
    category.images.forEach(image => {
        const imgElement = document.createElement('img');
        imgElement.src = `assets/img/products/${image}`;
        imgElement.alt = 'Product Image';
        imagesContainer.appendChild(imgElement);
    });
    document.getElementById('product-info').style.display = 'block';  // Show the container
}
